wrapper do
  name :test_wrapper
  plugin_id 'builtin'
  announced false
  parameters false
  xml do |_|
    test
  end
end

